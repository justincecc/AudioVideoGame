## Final Project

## Kitchen Escape
* Justin Ceccarelli (jac2524)
* Jensen Roe (jr2999)

## Instructions
Hit enter to start, once started you want to try to make it out of the kitchen and outdoors to plant yourself to win.
Avoid the enemies and collect as many mushrooms as possible

## Known Bugs or issues

Sometimes there's some catching on the edge on the right side of the room
That should be the only bug

## Credits
Justin Ceccarelli: Created character sprite, coin sprite, enemy sprite, platform sprite, and the background, created planting animation, start screen, end screen, character and enemy logic, 
Jensen Roe: Created and implemented the sounds